// Modal elements
const learnMoreModal = document.getElementById("learnMoreModal");
const journeyModal = document.getElementById("journeyModal");
const closeLearnMore = document.getElementById("closeLearnMore");
const closeJourney = document.getElementById("closeJourney");
const learnMoreBtn = document.getElementById("learnMoreBtn");
const modalTitle = document.getElementById("modalTitle");
const modalText = document.getElementById("modalText");
const modalList = document.getElementById("modalList");
const infoBtns = document.querySelectorAll(".info-btn");

// Data for our destinations (what's on the way)
const journeyData = {
    mountain: {
        title: "Mountain Summit Trail",
        text: "Your journey to the summit is filled with these key points:",
        points: [
            "🏔️ Кӯҳистон (0 mi): Parking, restrooms, and information kiosk.",
            "⛰️ Федченко (1.5 mi): First major viewpoint. Great for photos!",
            "🚰 Кавг чухма (2.8 mi): Freshwater spring to refill your bottles.",
            "🏞️ The Overlook (4.1 mi): Breathtaking 360-degree views of the valley.",
            "⛺ Summit Camp (5.5 mi): Designated resting area with emergency shelter."
        ]
    },
    mountains: {
        title: "Culture Explorer & Walk",
        text: "Discover the magic hidden along the path:",
        points: [
          "Old villlage  🌳(0.2 mi): A 500-year-old tree, the guardian of the forest.",
            "🌊 Whispering Village (0.7 mi): A small wooden bridge crosses this peaceful stream.",
            "🍄 Fairy Glen (1.1 mi): A small clearing known for unique fungi and butterflies.",
            "📜 Historian's Bench (1.6 mi): A bench with plaques describing the forest's history.",
            " 🐆 Snow Leopard (2.0 mi): A high chance of spotting wildlife in the early morning."
        ]
    }
};

// Open Learn More modal
learnMoreBtn.addEventListener('click', (e) => {
    e.preventDefault();
    learnMoreModal.style.display = 'flex';
});

// Close Learn More modal
closeLearnMore.addEventListener('click', () => {
    learnMoreModal.style.display = 'none';
});

// Function to open the journey modal and populate it with data
function openJourneyModal(destination) {
    const data = journeyData[destination];
    journeyModal.style.display = 'flex';
    modalTitle.textContent = data.title;
    modalText.textContent = data.text;
    
    // Clear previous list items
    modalList.innerHTML = '';
    
    // Add new list items
    data.points.forEach(point => {
        const listItem = document.createElement('li');
        listItem.textContent = point;
        modalList.appendChild(listItem);
    });
}

// Add click event to all "See The Journey" buttons
infoBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        const destination = btn.getAttribute('data-destination');
        openJourneyModal(destination);
    });
});

// Close the journey modal when the X is clicked
closeJourney.addEventListener('click', () => {
    journeyModal.style.display = 'none';
});

// Close modals if user clicks anywhere outside of them
window.addEventListener('click', (event) => {
    if (event.target == learnMoreModal) {
        learnMoreModal.style.display = 'none';
    }
    if (event.target == journeyModal) {
        journeyModal.style.display = 'none';
    }
});

// Simple form submission alert (for demo purposes)
document.querySelector('.contact-form').addEventListener('submit', function(e) {
    e.preventDefault(); // Stop the form from actually submitting
    alert('Thank you! In a real app, this message would be sent to the FarrukhAdvanture team. We will contact you soon!');
    this.reset(); // Clear the form
});